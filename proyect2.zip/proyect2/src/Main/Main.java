/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import javax.swing.*;
import java.awt.*;

class Punto {
	public float x;
	public float y;
	
	public Punto(float X, float Y) {
		this.x = x;
		this.y  = y;
	}
	
	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public String coord_cartesianas(){
		return "Cordenadas Cartesianas ("+ x +" , "+ y +")";
	}
	public String coord_polares() {
		double p1 = Math.sqrt(x * x + y * y);
		double p2 = Math.toDegrees(Math.atan2(y, x));
		return "Coordenadas polares ("+p1+" , "+p2+")";
	}
	public String toString(){
		return "punto ("+x+" , "+y+")";
		
	}

}


class Linea {
    private Punto p1, p2;

    public Linea(Punto p1, Punto p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    public String toString() {
        return "Linea (" + p1  + p2 +")";
    }

    public void dibujaLinea() {
        float d = Math.abs(p2.getX() - p1.getX());
        System.out.print(p1 + " ");
        for (int i = 0; i < d; i++) {
            System.out.print("-");
        }
        System.out.println(" " + p2);
    }
}

class Circulo {
    private Punto centro;
    private int radio;

    public Circulo(Punto centro, int radio) {
        this.centro = centro;
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Circulo: (Centro " + centro + ", Radio " + radio +")";
    }

    public void dibujaCirculo() {
        for (int i = -radio; i <= radio; i++) {
            for (int j = -radio; j <= radio; j++) {
                if (Math.abs(Math.sqrt(i * i + j * j) - radio) < 0.5) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}


public class Main {
    public static void main(String[] args) {
        Punto p1 = new Punto(2, 5);
        Punto p2 = new Punto(10, 9);
        Linea linea = new Linea(p1, p2);
        Circulo circulo = new Circulo(new Punto(5, 5), 5);

        System.out.println(linea);
        linea.dibujaLinea();
        System.out.println("-----------------------------");
        System.out.println(circulo);
        circulo.dibujaCirculo();
    }
}

